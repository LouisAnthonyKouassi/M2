class CreatePizzas < ActiveRecord::Migration[5.1]
  def change
    create_table :pizzas do |t|
      t.string :DesignPizz
      t.numeric :TarifPizz
      t.string :ImagePizz

      t.timestamps
    end
  end
end
